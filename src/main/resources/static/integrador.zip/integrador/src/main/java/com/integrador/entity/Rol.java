package com.integrador.entity;

public enum Rol {
    USER, ADMIN
}
